/**
 * 雑多な関数 (主に SDP 用)
 * 最終更新日: 2025-07-14
 */

// 画面切り替え待ち
export const waitForLoaded = async (locator) => {
  await expect(locator).toBeVisible();
  await expect(locator).not.toBeVisible();
};

// ページの一番上にスクロールする
const pageTop = async (page) => {
  await page.keyboard.press('Home');
};

// ページの一番下にスクロールする
const pageBottom = async (page) => {
  await page.keyboard.press('End');
};

// フォーム入力 (シングルライン、マルチライン)
export const setTextForm = async (locator, label, value) => {
  await locator
    .locator('div.col-fields').filter({ hasText: label })
    .locator('input')
    .fill(value);
};

// フォーム入力 (検索して選択、ピックリスト)
export const setListForm = async (locator, label, value) => {
  await locator
    .locator('div.col-fields').filter({ hasText: label })
    .locator('a.select2-choice')
    .click();
  // div.select2-result-label[role="option"]
  await locator.getByRole('option', { name: value }).click();
};

// フォーム入力 (ラジオボタン)
export const setRadioForm = async (locator, label, value) => {
  await locator
    .locator('div.col-fields').filter({ hasText: label })
    .getByRole('radio', { name: value })
    .check();
};

// フォーム入力 (チェックボックス)
export const setCheckForm = async (locator, label, ...values) => {
  // この回し方の方が安定する(?)
  for (const value of values) {
    await locator
      .locator('div.col-fields').filter({ hasText: label })
      .getByRole('checkbox', { name: value })
      .check();
  }
};

// フォーム入力 (HTML エディター)
export const setHtmlForm = async (locator, label, value) => {
  await locator
    .locator('div.col-fields').filter({ hasText: label })
    .locator('iframe.ze_area').contentFrame()
    .locator('[contenteditable="true"]')
    .fill(value);
};

// フォーム入力 (右パネル)
export const setRightPanelForm = async (page, label, value) => {

  const div = await page
    .locator('#right-panel')
    .locator('div.form-group').filter({ hasText: label });

  // フォームを活性化
  await div.locator('p').click();

  // フィールドの種類別の選択処理
  switch (label) {
    case 'ステータス':
    case '優先度':
      await div.locator('select').waitFor();
      await div.locator('select').selectOption(value);
      await div.locator('#saveStatusButton').click();
      break;
    case '技術担当者':
    case 'グループ':
      const dialog = page.getByRole('dialog', { name: '技術担当者の割り当て' });
      await dialog
        .locator('div.form-group').filter({ hasText: label })
        .locator('a.select2-choice')
        .click();
      await page.getByRole('option', { name: value }).click();
      await dialog.getByRole('button', { name: '割り当て', exact: true }).click();
      await expect(dialog).not.toBeVisible();
      break;
    default:
  }
};

//