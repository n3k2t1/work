// @ts-check
import { test, expect } from '@playwright/test';
import * as sdp from '../../utils/zoho-sdp';

// test('', { tag: '' }, async ({ page }) => {});
// await test.step('ログイン', async () => {});

// https://192.168.20.101:8080
// administrator
// z6R|i)qA

const reqId = 18;

test('技術担当者', { tag: ['@sdp', '@tech'] }, async ({ page }) => {

  await test.step('ログイン', async () => {
    // ナビゲーション
    await page.goto('https://192.168.20.101:8080');
    await expect(page).toHaveTitle(/ServiceDesk Plus/);
    // アクション
    await page.getByRole('textbox', { name: 'ユーザー名' }).fill('administrator');
    await page.getByRole('textbox', { name: 'パスワード' }).fill('z6R|i)qA');
    await page.getByRole('button', { name: 'ログイン' }).click();
    // マッチャー
    await expect(page).toHaveURL(/\/HomePage\.do/);
    await expect(page.getByRole('link', { name: 'ホーム', exact: true })).toBeVisible();
  });

  // ----------------------------------------
  await test.step('リクエスト/リストビューを開く', async () => {
    // アクション
    await page.getByRole('link', { name: 'リクエスト', exact: true }).click();
    // 画面切り替え待ち
    await expect(page).toHaveURL(/\/WOListView\.do/);
    // await waitForLoaded(page.locator('#req_skloader'));
    await expect(page.locator('#ListViewFilterMenu')).toBeInViewport();
  });

  // ----------------------------------------
  await test.step.skip('リクエスト/リクエストビューを開く', async () => {
    // アクション
    await page.getByTitle(`<strong>リクエストID :</strong>${reqId}<`).click();
    // マッチャー
    await expect(page).toHaveURL(new RegExp(`\\/WorkOrder\\.do\\?woMode=viewWO&woID=${reqId}`));
    // await waitForLoaded(page.locator('#req_details_skloader'));
    await expect(page.locator('#request-id')).toBeInViewport();
  });

  // ----------------------------------------
  await test.step('リクエスト/リクエストを追加する/デフォルトテンプレート', async () => {
    await page.getByTitle('新規リクエスト作成のためのデフォルトテンプレート').click();
    await expect(page.getByRole('heading', { name: 'リクエストの追加' })).toBeInViewport();
  });

  await test.step.skip('リクエスト/リクエストを追加する/テンプレート選択スライダー', async () => {
    // アクション
    await page.getByRole('link', { name: '新規リクエスト', exact: true }).click();
    // マッチャー
    // await expect(page.locator('#ticket-raise')).toBeVisible();
    await expect(page.getByText('リクエストを起票')).toBeVisible();
  });

  await test.step('リクエスト/リクエストを追加する/フォーム入力 & 保存', async () => {
    // アクション
    await sdp.setTextForm(page, '件名', '件名の文字列');
    await sdp.setListForm(page, '緊急度', 'Low');
    await sdp.setRadioForm(page, 'ラジオフォーム', 'BBB');
    await sdp.setListForm(page, '依頼者', 'Howard Stern');
    await sdp.setListForm(page, '優先度', 'High');
    await sdp.setHtmlForm(page, '説明', '説明の文字列');
    await sdp.setCheckForm(page, 'チェックボックスフォーム', '111', '333');
    await page.getByRole('button', { name: 'リクエストの追加' }).click();
    // マッチャー
    await expect(page).toHaveURL(/\/WorkOrder\.do\?woMode=viewWO&woID=\d+/);
    // await waitForLoaded(page.locator('#req_details_skloader'));
    await expect(page.locator('#request-id')).toBeInViewport();
  });

  await test.step.skip('リクエスト/右パネルで編集', async () => {
    await sdp.setRightPanelForm(page, '技術担当者', 'John Roberts');;
  });

  // ----------------------------------------
  await test.step.skip('ソリューション/リストビューを開く', async () => {
    // アクション
    await page.getByRole('link', { name: 'ソリューション', exact: true }).click();
    // マッチャー
    await expect(page).toHaveURL(/\/ui\/solutions\?mode=list/);
    // 一つ前のローダー
    // await waitForLoaded(page.locator('#solution_skloader'));
    await sdp.waitForLoaded(page.locator('#solutions_div').locator('.loading1'));
  });

  await test.step.skip('ソリューション/ソリューションを追加する/入力画面を開く', async () => {
    await page.getByTitle('新規ソリューション').click();
    await expect(page.getByRole('heading', { name: '新規 ソリューション' })).toBeVisible();
  });

  await test.step.skip('ソリューション/ソリューションを追加する/フォーム入力 & 保存', async () => {
    // アクション
    await sdp.setTextForm(page, '件名', '件名の文字列');
    await sdp.setHtmlForm(page, '内容', '内容の文字列');
    await sdp.setListForm(page, 'トピック', 'Desktop Hardware');
    await page.getByRole('button', { name: '保存', exact: true }).click();
    // マッチャー
    await expect(page).toHaveURL(/\/ui\/solutions\?entity_id=\d+&mode=detail/);
    // 同じクラスのローダーが 左-中-右 の3つ存在する
    await sdp.waitForLoaded(page.locator('.skeleton-loading').nth(1));
  });

});

//